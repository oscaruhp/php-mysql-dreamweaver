<?php 

$a=true;
$b=false;

//operadores lógicos 
var_dump($a and $b);

// operadores de comparación
var_dump($a == $b);


?>